# Shailu Bhai Daily Collection — Android APK

Android WebView wrapper around the existing Shailu Bhai Daily Collection HTML app.

- No advertising SDK.
- WhatsApp links are handed to Android using ACTION_VIEW.
- Native Android share sheet is exposed to the web app.
- Local IndexedDB/DOM storage is enabled.
- HTML file import is supported through Android's document picker.
- GitHub Actions builds a debug APK and uploads it as an artifact.
